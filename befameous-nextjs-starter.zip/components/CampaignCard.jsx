import Link from 'next/link';

export default function CampaignCard({ c }) {
  return (
    <div className="card p-5 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">{c.title}</h3>
        <span className="text-sm text-white/70">{c.budget ? `€${c.budget}` : ''}</span>
      </div>
      <p className="text-white/80 text-sm">{c.description}</p>
      <div className="text-xs text-white/60">Brand: {c.brandName || '—'}</div>
      {c.id && (
        <Link href={`/campaigns?id=${c.id}`} className="btn btn-ghost mt-2 w-fit">Detalii</Link>
      )}
    </div>
  );
}
