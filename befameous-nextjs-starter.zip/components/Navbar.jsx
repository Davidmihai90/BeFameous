'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { clsx } from 'clsx';
import Image from 'next/image';

export default function Navbar() {
  const pathname = usePathname();
  const link = (href, label) => (
    <Link
      href={href}
      className={clsx(
        'px-3 py-2 rounded-lg hover:bg-white/10 transition',
        pathname === href && 'bg-white/15'
      )}
    >
      {label}
    </Link>
  );

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/60 backdrop-blur supports-[backdrop-filter]:bg-black/40">
      <div className="container-p flex items-center gap-4 py-3">
        <Link href="/" className="flex items-center gap-2">
          <Image src="/logo.svg" alt="BeFameous" width={36} height={36} priority />
          <span className="text-lg font-semibold tracking-wide">BeFameous</span>
        </Link>
        <nav className="ml-auto flex items-center gap-1">
          {link('/', 'Acasă')}
          {link('/campaigns', 'Campanii')}
          {link('/dashboard/brand', 'Dashboard Brand')}
          {link('/dashboard/influencer', 'Dashboard Influencer')}
          {link('/login', 'Login')}
        </nav>
      </div>
    </header>
  );
}
