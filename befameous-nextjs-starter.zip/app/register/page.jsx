'use client';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { auth, db } from '@/lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function Register() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '', name: '', role: 'influencer' });
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const cred = await createUserWithEmailAndPassword(auth, form.email, form.password);
      await updateProfile(cred.user, { displayName: form.name });
      await setDoc(doc(db, 'users', cred.user.uid), {
        uid: cred.user.uid,
        displayName: form.name,
        email: form.email,
        role: form.role,
        bio: '',
        photoURL: cred.user.photoURL || '',
        createdAt: Date.now()
      });
      router.push(`/dashboard/${form.role}`);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-md mx-auto card p-6">
      <h2 className="text-2xl font-semibold mb-4">Creează cont</h2>
      <form onSubmit={submit} className="space-y-3">
        <input className="w-full px-3 py-2 rounded-lg bg-white/10 outline-none" placeholder="Nume afișat"
               value={form.name} onChange={(e)=>setForm({...form, name: e.target.value})} />
        <input className="w-full px-3 py-2 rounded-lg bg-white/10 outline-none" placeholder="Email"
               value={form.email} onChange={(e)=>setForm({...form, email: e.target.value})} />
        <input type="password" className="w-full px-3 py-2 rounded-lg bg-white/10 outline-none" placeholder="Parolă (min 6)"
               value={form.password} onChange={(e)=>setForm({...form, password: e.target.value})} />
        <div className="flex gap-3">
          <label className={`flex-1 card p-3 cursor-pointer ${form.role==='brand'?'ring-2 ring-brand':''}`}>
            <input type="radio" name="role" className="hidden" checked={form.role==='brand'}
                   onChange={()=>setForm({...form, role:'brand'})} />
            <div className="font-medium">Brand</div>
            <div className="text-xs text-white/60">Postează campanii</div>
          </label>
          <label className={`flex-1 card p-3 cursor-pointer ${form.role==='influencer'?'ring-2 ring-brand':''}`}>
            <input type="radio" name="role" className="hidden" checked={form.role==='influencer'}
                   onChange={()=>setForm({...form, role:'influencer'})} />
            <div className="font-medium">Influencer</div>
            <div className="text-xs text-white/60">Aplică la campanii</div>
          </label>
        </div>
        {error && <div className="text-sm text-red-400">{error}</div>}
        <button className="btn-primary w-full" type="submit">Creează cont</button>
      </form>
    </div>
  );
}
