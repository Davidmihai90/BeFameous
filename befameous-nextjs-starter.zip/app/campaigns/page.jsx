'use client';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useEffect, useState } from 'react';
import CampaignCard from '@/components/CampaignCard';

export default function Campaigns() {
  const [list, setList] = useState([]);

  useEffect(() => {
    const load = async () => {
      const snap = await getDocs(collection(db, 'campaigns'));
      setList(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    };
    load();
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Campanii disponibile</h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(c => <CampaignCard key={c.id} c={c} />)}
      </div>
    </div>
  );
}
