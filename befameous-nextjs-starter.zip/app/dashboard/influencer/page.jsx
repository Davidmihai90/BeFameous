'use client';
import { useAuth } from '@/components/AuthProvider';
import { db } from '@/lib/firebase';
import { collection, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import CampaignCard from '@/components/CampaignCard';

export default function InfluencerDashboard() {
  const { user, profile, loading } = useAuth();
  const [list, setList] = useState([]);
  const [status, setStatus] = useState('');

  useEffect(() => {
    const load = async () => {
      const snap = await getDocs(collection(db, 'campaigns'));
      setList(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    };
    load();
  }, []);

  const apply = async (campaignId) => {
    if (!user) return setStatus('Te rog autentifică-te.');
    await addDoc(collection(db, 'campaigns', campaignId, 'applications'), {
      uid: user.uid,
      profile: {
        displayName: profile?.displayName || user.email,
        role: profile?.role || 'influencer'
      },
      createdAt: serverTimestamp()
    });
    setStatus('Ai aplicat la campanie!');
    setTimeout(()=>setStatus(''), 2500);
  };

  if (loading) return <div>Se încarcă...</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard Influencer</h1>
      {status && <div className="text-sm text-green-400">{status}</div>}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(c => (
          <div key={c.id} className="card p-5">
            <CampaignCard c={c} />
            <button onClick={()=>apply(c.id)} className="btn-primary mt-3 w-full">Aplică</button>
          </div>
        ))}
      </div>
    </div>
  );
}
