'use client';
import { useAuth } from '@/components/AuthProvider';
import { db } from '@/lib/firebase';
import { addDoc, collection, serverTimestamp, query, where, getDocs } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import CampaignCard from '@/components/CampaignCard';

export default function BrandDashboard() {
  const { user, profile, loading } = useAuth();
  const [form, setForm] = useState({ title: '', description: '', budget: '', brandName: '' });
  const [list, setList] = useState([]);

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      const q = query(collection(db, 'campaigns'), where('owner', '==', user.uid));
      const snap = await getDocs(q);
      setList(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    };
    load();
  }, [user]);

  const create = async (e) => {
    e.preventDefault();
    if (!user) return;
    await addDoc(collection(db, 'campaigns'), {
      owner: user.uid,
      brandName: form.brandName || profile?.displayName || 'Brand',
      title: form.title,
      description: form.description,
      budget: Number(form.budget) || null,
      createdAt: serverTimestamp(),
      status: 'open'
    });
    setForm({ title: '', description: '', budget: '', brandName: '' });
    // reload
    const q = query(collection(db, 'campaigns'), where('owner', '==', user.uid));
    const snap = await getDocs(q);
    setList(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  };

  if (loading) return <div>Se încarcă...</div>;
  if (!user) return <div className="text-white/70">Te rog autentifică-te.</div>;
  if (profile?.role !== 'brand') return <div className="text-white/70">Acesta este dashboard-ul pentru Brand.</div>;

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Dashboard Brand</h1>

      <form onSubmit={create} className="card p-5 grid md:grid-cols-2 gap-4">
        <input className="px-3 py-2 rounded-lg bg-white/10" placeholder="Nume brand"
               value={form.brandName} onChange={(e)=>setForm({...form, brandName: e.target.value})} />
        <input className="px-3 py-2 rounded-lg bg-white/10" placeholder="Titlu campanie"
               value={form.title} onChange={(e)=>setForm({...form, title: e.target.value})} />
        <input className="px-3 py-2 rounded-lg bg-white/10" placeholder="Buget (€)"
               value={form.budget} onChange={(e)=>setForm({...form, budget: e.target.value})} />
        <textarea className="md:col-span-2 px-3 py-2 rounded-lg bg-white/10" rows={4} placeholder="Descriere"
               value={form.description} onChange={(e)=>setForm({...form, description: e.target.value})} />
        <button className="btn-primary md:col-span-2" type="submit">Creează campanie</button>
      </form>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map(c => <CampaignCard key={c.id} c={c} />)}
      </div>
    </div>
  );
}
