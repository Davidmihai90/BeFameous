'use client';
import { signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '@/lib/firebase';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  const login = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push('/dashboard/influencer');
    } catch (err) {
      setError(err.message);
    }
  };

  const loginGoogle = async () => {
    setError('');
    try {
      await signInWithPopup(auth, googleProvider);
      router.push('/dashboard/influencer');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-md mx-auto card p-6">
      <h2 className="text-2xl font-semibold mb-4">Autentificare</h2>
      <form onSubmit={login} className="space-y-3">
        <input className="w-full px-3 py-2 rounded-lg bg-white/10 outline-none" placeholder="Email"
               value={email} onChange={(e)=>setEmail(e.target.value)} />
        <input type="password" className="w-full px-3 py-2 rounded-lg bg-white/10 outline-none" placeholder="Parolă"
               value={password} onChange={(e)=>setPassword(e.target.value)} />
        {error && <div className="text-sm text-red-400">{error}</div>}
        <button className="btn-primary w-full" type="submit">Intră în cont</button>
      </form>
      <div className="my-4 text-center text-white/60">sau</div>
      <button onClick={loginGoogle} className="btn-ghost w-full">Continuă cu Google</button>
    </div>
  );
}
